#include<stdio.h>
#include<string.h>
void encrypt(char str[],int n,int shift)
{
	for(int i=0;i<n;i++)
	{
		if(islower(str[i]))
			str[i]=((str[i]-97+shift)%26)+97;
		else
			str[i]=((str[i]-65+shift)%26)+65;		
	}
}
void decrypt(char str[],int n,int shift)
{
	for(int i=0;i<n;i++)
	{
		if(islower(str[i]))
			str[i]=((str[i]-97-shift+26)%26)+97;
		else
			str[i]=((str[i]-65-shift+26)%26)+65;		
	}
}
void main()
{
int n,shift;
char str[100];
printf("Enter the text : \n");
scanf("%s",str);
n=strlen(str);
printf("Enter the value by which you want to shift : \n");
scanf("%d",&shift);
printf("On Encryption our text is : \n");
encrypt(str,n,shift);
printf("%s\n", str);
printf("On Decryption our text is : \n");
decrypt(str,n,shift);
printf("%s\n", str);
return;
}


