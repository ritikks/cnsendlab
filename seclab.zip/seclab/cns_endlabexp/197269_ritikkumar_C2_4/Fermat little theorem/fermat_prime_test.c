#include<gmp.h>
#include<time.h>
#include<stdio.h>
void main()
{
mpz_t n,rand_num,power_var,rop,k;
mpz_inits(n,rand_num,power_var,rop,k,NULL);
gmp_printf("\n enter value of the number you want to test for prime : ");
gmp_scanf("%Zd",n);
mpz_set_ui (k,10);
gmp_randstate_t state;
unsigned long int seed=time(NULL);
gmp_randinit_mt(state);
gmp_randseed_ui (state,seed);
while(mpz_cmp_ui (k,0))
	{
		mpz_sub_ui (rand_num, n, 3);
		mpz_urandomm (rand_num, state, rand_num);
		mpz_add_ui (rand_num, rand_num, 2);  // random number generated
		
		mpz_sub_ui (power_var, n, 1); // exponential term
		mpz_powm (rop, rand_num, power_var, n);
		if(mpz_cmp_ui (rop,1))  // if equal then 0
		{
		gmp_printf("\n the number is a composite number \n");
		return;
		}
		mpz_sub_ui (k, k, 1);
	}
	gmp_printf("\n the number is a prime number \n ");
}
