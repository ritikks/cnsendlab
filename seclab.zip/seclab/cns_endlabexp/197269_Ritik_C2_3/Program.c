#include<stdio.h>
#include<stdlib.h>
//ADDition of polynimals
void  ADD(char res[],char A[],char B[],int n){
    for(int i=0;i<=n;i++)
    {
        // printf("%c  %c\n",A[i],B[i]);
      if((A[i]=='0' && B[i]=='0') || (A[i]=='1' && B[i]=='1'))
      {
        res[i]='0';
      }
      else{
        res[i]='1';
      }
    }
}

//Substraction of polynimals
void  Sub(char res[],char A[],char B[],int n){
    for(int i=0;i<=n;i++)
    {
        // printf("%c  %c\n",A[i],B[i]);
      if((A[i]=='0' && B[i]=='0') || (A[i]=='1' && B[i]=='1'))
      {
        res[i]='0';
      }
      else{
        res[i]='1';
      }
    }
}

//Multiplication of polynimals
int  MUL(int a,int b){
    int res=0;
    while(a)
    {
       if(a&1)
       {
           res^=b;
       }
       a>>=1;
       b<<=1;
    }
    return res;
}
void Display(char res[],int n)
{
   for(int i=0;i<=n;i++)
    { 
      
        if(res[i]=='1')
        {
           printf("x^%d",(n-i));
           if(i<n)
            {
                printf(" + ");
            }
        }
      
       
    }
    printf("\n");
}
int get_int_from_binaryString(char A[],int n)
{
    int res=0;
    int pow2=1;
    for(int i=n;i>=0;i--)
    {
        if(A[i]=='1')
        res+=pow2 ;
        pow2<<=1;
    }
    printf("\n");
    return res;
}
void display_(int n){
    char res[100];
    int size=0;
    while(n)
    {
        if(n&1)res[size]='1';
        else res[size]='0';
       size++;
       n>>=1;
    }
    res[size]='0';
    int i=0,j=size;
    
    while(i<j)
    {
      char ch=res[i];
      res[i]=res[j];
      res[j]=ch;
      i++;
      j--;
      
    }
     for(int i=0;i<=size;i++)
    {
        printf("%c",res[i]);
    }
    printf("\n                  ");
    Display(res,size);
    
}
int degree(int n)
{
   if(n==0) return -1;   
    int deg=0;
    while(n)
    {
        deg++;
        n>>=1;
    }
    return deg -1;
}
int DIV(int a,int b)
{
    if(b==0) return 0;
    if(a<0) return 0;
    int res=a;
    while(degree(res) >=degree(b))
    {
        int pos=(degree(res)-degree(b));
        res=res^(b<<pos);
    }
    return res;
    
}
int main()
{
    printf("Submitted BY : \n   Name : Sunny Singariya \n   Roll no. 197180 \n   Btech CSE 4th Year\n");
    int n;//degree of polynomial
    printf("Enter Degree of Polynomial : ");
   scanf("%d", &n);
   //input  of  polynomial in  bit form  
   // example :  x^3 + x + 1 =>  1011
   char  A[100];
   char B[100];
   printf("Enter Polynomial in Binary string Form \n example :  x^3 + x + 1 =>  1011\n");
    printf("Enter Polynomial f(x) : ");
   scanf("%s", A);
   printf("f(x) = ");
     Display(A,n);
    printf("Enter Polynomial g(x) : ");
   scanf("%s", B);
   printf("g(x) = ");
     Display(B,n);
    char  res[20];
   // ADDITION of Polynomials
    ADD(res,A,B,n);
    printf("-------------------------------\n");
    printf("          ADDITION          \n");
    printf("\n");
    printf("Addition of Polynomials is  : ");
    for(int i=0;i<=n;i++)
    {
        printf("%c",res[i]);
    }
    printf("\n                  ");
    Display(res,n);
    printf("\n");
    printf("-------------------------------\n");

  // Substraction of Polynomials
    Sub(res,A,B,n);
    printf("          SUBSTRACTION           \n");
    printf("\n");
    printf("Substraction of Polynomials is  : ");
    for(int i=0;i<=n;i++)
    {
        printf("%c",res[i]);
    }
    printf("\n                  ");
    Display(res,n);
    printf("\n");
    printf("-------------------------------\n");
    
     int a=0;
    int b=0;
    a=get_int_from_binaryString(A,n);
    b=get_int_from_binaryString(B,n);
    
    
     // Multiplication of Polynomials
    int mul=MUL(a,b);
    printf("          MULTIPLICATION           \n");
    printf("\n");
    printf("Multiplication of Polynomials is  : ");
    display_(mul);
    printf("\n");
    printf("-------------------------------\n");

     // Division of Polynomials
    int div_=DIV(a,b);
    printf("          DIVISION          \n");
    printf("\n");
    printf("Division of Polynomials is  : ");
    display_(div_);
    printf("\n");
    printf("-------------------------------\n");


}
