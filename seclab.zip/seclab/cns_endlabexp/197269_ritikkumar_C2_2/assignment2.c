#include<gmp.h>
#include<stdio.h>
void main()
{

mpz_t a,res,temp;
mpz_inits(a,res,temp,NULL);
mpz_set_ui(temp,1);
mpz_mul_2exp(a,temp,1023);
mpz_sub_ui(a,a,1);
mpz_nextprime(res,a);
gmp_printf("prime number of 1024 bits is : %Zd",res);
}
