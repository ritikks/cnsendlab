#include<gmp.h>
#include<stdio.h>
void main()
{
   mpz_t a,b,c;
   mpz_inits(a,b,c,NULL);
   gmp_printf("\n Enter the value of A \n");
   gmp_scanf("%Zd",a);
   gmp_printf("\n Enter the value of B\n");
    gmp_scanf("%Zd",b);
   //adding two numbers
    mpz_add(c,a,b);
    gmp_printf("\na+b =%Zd",c);
   //sub two numbers  
   mpz_sub(c,a,b);
    gmp_printf("\na-b =%Zd",c);   
    // mul 2 numbers
     mpz_mul(c,a,b);
    gmp_printf("\na*b =%Zd",c);   
    // div 2 numbers
     mpz_fdiv_q(c,a,b);
    gmp_printf("\na/b =%Zd",c);  
    // mod of 2 numbers
     mpz_mod(c,a,b);
    gmp_printf("\na%b =%Zd",c);    
    
    
   
}
