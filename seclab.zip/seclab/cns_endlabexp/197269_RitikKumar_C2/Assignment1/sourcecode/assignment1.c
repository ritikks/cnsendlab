#include<gmp.h>
#include<stdio.h>
void main()
{ 
     mpz_t a,b,t;
   mpz_inits(a,b,t,NULL);
   gmp_printf("\n Enter the value of A \n");
   gmp_scanf("%Zd",a);
   gmp_printf("\n Enter the value of B\n");
    gmp_scanf("%Zd",b);
    
    while(mpz_cmp_ui(b,0)!=0)
    {
   
      mpz_set(t,b);
      mpz_mod(b,a,b);
      mpz_set(a,t);
      
    }
     gmp_printf("\n GCD is %Zd \n",a );
    
  
}
